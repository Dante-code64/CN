-- ============================================================
-- Crydan — Sistema de "Seguir" (estilo Instagram)
--
-- Diferente do sistema de Amizade (que exige pedido + aceite), Seguir
-- é de mão única: qualquer conta pode seguir o perfil público de
-- outra a qualquer momento, sem aprovação. É o que dá os contadores
-- de "seguidores" / "seguindo" e o botão "Seguir" no modal de perfil
-- público (ver openPublicProfile / renderPublicProfileModal / toggleFollow
-- no index.html).
--
-- Pré-requisito: já ter rodado social-setup.sql e public-profile-setup.sql
-- antes (usa a tabela "profiles" e a autenticação do Supabase).
--
-- Rode este arquivo inteiro no SQL Editor do Supabase, uma vez
-- (Supabase → seu projeto → SQL Editor → New query → colar → Run).
-- Já foi aplicado neste projeto (mkwqkedrnmzhyrpwzpse) — este arquivo
-- fica aqui só como documentação/histórico do schema.
-- ============================================================

create table if not exists public.follows (
  follower_id uuid not null references auth.users(id) on delete cascade,
  followed_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id, followed_id),
  constraint follows_no_self check (follower_id <> followed_id)
);

create index if not exists follows_followed_idx on public.follows (followed_id);
create index if not exists follows_follower_idx on public.follows (follower_id);

alter table public.follows enable row level security;

drop policy if exists "follows_select_all" on public.follows;
create policy "follows_select_all" on public.follows
  for select using (auth.role() = 'authenticated');

drop policy if exists "follows_insert_own" on public.follows;
create policy "follows_insert_own" on public.follows
  for insert with check (follower_id = auth.uid());

drop policy if exists "follows_delete_own" on public.follows;
create policy "follows_delete_own" on public.follows
  for delete using (follower_id = auth.uid());
