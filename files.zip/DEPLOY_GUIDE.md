# Como colocar o Crydan no ar (passo a passo bem simples)

## O que já está pronto
- `index.html` — o app inteiro, já conectado ao seu banco de dados real no Supabase (projeto "Crydan", `mkwqkedrnmzhyrpwzpse`).
- As tabelas `saves` e `app_settings` já foram criadas no seu Supabase, com segurança (cada pessoa só vê e edita os próprios dados).
- `vite.config.js`, `vercel.json`, `package.json` — arquivos que dizem pro Vercel como construir e publicar o site.

Não precisa configurar nenhuma senha ou chave na Vercel — a chave pública do Supabase já está dentro do `index.html` (isso é seguro, é assim que o Supabase é feito pra funcionar).

## Passo 1 — Colocar os arquivos no GitHub
1. Entre em [github.com](https://github.com) e crie um repositório novo (pode ser privado).
2. Suba todos os arquivos desta pasta pra esse repositório (dá pra arrastar e soltar direto no site do GitHub, em "Add file → Upload files").

## Passo 2 — Conectar com a Vercel
1. Entre em [vercel.com](https://vercel.com) e faça login (dá pra usar sua conta do GitHub).
2. Clique em **"Add New..." → "Project"**.
3. Escolha o repositório que você acabou de criar.
4. A Vercel já vai reconhecer que é um projeto Vite sozinha (por causa do `vercel.json`). Não precisa mudar nada.
5. Clique em **"Deploy"**.

## Passo 3 — Pronto!
Em cerca de 1 minuto, a Vercel te dá um link (tipo `crydan.vercel.app`). Esse link já é o app funcionando, com banco de dados de verdade.

## Uma coisa pra você verificar no Supabase
No painel do Supabase, em **Authentication → Settings**, tem uma opção "Confirm email". Se ela estiver **ligada**, quem criar conta precisa clicar num link no e-mail antes de conseguir entrar. Se você quiser que a pessoa entre na hora, sem confirmar e-mail, é só desligar essa opção lá.

## Se quiser testar no seu computador antes
```
npm install
npm run dev
```
Isso abre o app localmente pra você testar antes de publicar.
